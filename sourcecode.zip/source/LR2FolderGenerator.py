﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LR2 Folder Generator with GUI (RANDOM & BPM)
ランダムフォルダとBPMフォルダを生成するツール
"""

import os
import sys
import re
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter import scrolledtext
import threading
import shutil
import sqlite3

class FolderGenerator:
    """フォルダ生成基底クラス"""
    
    def __init__(self):
        self.encoding = 'shift_jis'
        self.folder_path = None
        self.difficulties = []
        self.playlist_id = None
        self.category_name = None
        self.max_difficulty_value = 0  # パディング判定用
    
    def detect_difficulties(self, folder_path):
        """
        フォルダ内から難易度系フォルダを検出
        """
        self.difficulties = []
        difficulty_set = {}
        
        lr2_files = list(Path(folder_path).glob('*.lr2folder'))
        if not lr2_files:
            return False, "このフォルダは難易度表フォルダではないか、.lr2folderファイルが見つかりません"
        
        for lr2_file in sorted(lr2_files):
            try:
                with open(lr2_file, 'r', encoding=self.encoding) as f:
                    content = f.read()
                
                command_match = re.search(
                    r"#COMMAND\s+song\.hash\s+in\s+\(SELECT.*?WHERE\s+playlist_id\s*=\s*(\d+).*?AND\s+folder\s*=\s*'([^']+)'",
                    content,
                    re.DOTALL
                )
                
                if command_match:
                    playlist_id = int(command_match.group(1))
                    folder_name = command_match.group(2)
                    
                    if not self.playlist_id:
                        self.playlist_id = playlist_id
                    
                    sort_key = self._extract_sort_key(folder_name)
                    difficulty_set[sort_key] = (folder_name, folder_name)
                    
                    if not self.category_name:
                        category_match = re.search(r"#CATEGORY\s+(.+)", content)
                        if category_match:
                            self.category_name = category_match.group(1)
            
            except Exception as e:
                return False, f"ファイル読込エラー: {lr2_file.name}\n{str(e)}"
        
        if not difficulty_set:
            return False, "難易度情報が検出されませんでした"
        
        self.difficulties = [difficulty_set[key] for key in sorted(difficulty_set.keys())]
        
        # 最大難易度値を記録（パディング判定用）
        self.max_difficulty_value = 0
        for folder_name, _ in self.difficulties:
            num_match = re.search(r'(-?\d+(?:\.\d+)?)', folder_name)
            if num_match:
                try:
                    num = float(num_match.group(1))
                    if num > self.max_difficulty_value:
                        self.max_difficulty_value = num
                except ValueError:
                    pass
        
        # パディング処理は最大値計算後に適用
        # DebugGUIに表示するための形式
        debug_msg = f"{len(self.difficulties)}個の難易度レベルを検出しました\n\n検出順序:\n"
        for folder, title in self.difficulties:
            debug_msg += f"  {folder}\n"
        
        return True, debug_msg
    
    def _extract_sort_key(self, folder_name):
        """ソートキーを抽出（小数点・マイナス対応）"""
        # 「LEVEL」を削除してから処理
        base_name = folder_name.replace('LEVEL ', '').strip()
        
        # プレフィックス部分を抽出（dl, subdl など）
        prefix_match = re.match(r'([a-zA-Z]+)', base_name)
        prefix = prefix_match.group(1) if prefix_match else ''
        
        # 数値を抽出
        num_match = re.search(r'(-?\d+(?:\.\d+)?)', base_name)
        if num_match:
            try:
                num = float(num_match.group(1))
                # （プレフィックス, 数値）でソート
                return (0, prefix, num)
            except ValueError:
                return (1, base_name)
        else:
            return (1, base_name)
    
    def _sanitize_filename(self, filename):
        """ファイル名に使用できない文字を全角に置換"""
        # Windows で使用不可な文字を全角に置換
        replacements = {
            '<': '＜',
            '>': '＞',
            ':': '：',
            '"': '＂',
            '/': '／',
            '\\': '＼',
            '|': '｜',
            '?': '？',
            '*': '＊',
            '!': '！',
        }
        sanitized = filename
        for invalid_char, full_width in replacements.items():
            sanitized = sanitized.replace(invalid_char, full_width)
        return sanitized
    
    def _pad_folder_name(self, folder_name):
        """
        難易度が2桁以上の場合、0パディングを適用
        マイナスの場合はスペース2つ + マイナスで先頭にソート
        """
        # マイナス処理
        if '_-' in folder_name or ' -' in folder_name:
            folder_name = folder_name.replace('_-', '  -').replace(' -', '  -')
        
        # 最大難易度が10以上なら0パディングを適用
        if self.max_difficulty_value >= 10:
            # マイナスでないもののみパディング
            if '_-' not in folder_name and ' -' not in folder_name:
                match = re.search(r'(\d+)(?:\.(\d+))?$', folder_name)
                if match:
                    integer_part = int(match.group(1))
                    decimal_part = match.group(2) if match.group(2) else ""
                    base = folder_name[:match.start()]
                    
                    if decimal_part:
                        return f"{base}{integer_part:02d}.{decimal_part}"
                    else:
                        return f"{base}{integer_part:02d}"
        
        return folder_name


class RandomFolderGenerator(FolderGenerator):
    """ランダムフォルダ生成クラス"""
    
    def create_random_folders(self, include_all_random=True):
        """ランダムフォルダを生成"""
        if not self.folder_path or not self.difficulties or not self.playlist_id:
            return False, "フォルダ情報が不完全です"
        
        random_folder = Path(self.folder_path) / "RANDOM"
        # 既存ファイルをクリア
        if random_folder.exists():
            for file in random_folder.glob('*.lr2folder'):
                file.unlink()
        random_folder.mkdir(exist_ok=True)
        
        created_files = []
        
        try:
            for idx, (folder_name, title) in enumerate(self.difficulties):
                padded_folder_name = self._pad_folder_name(folder_name)
                lines = [
                    f"#COMMAND song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND folder = '{folder_name}' AND is_removed = 0)",
                    "#MAXTRACKS 1",
                    "#CATEGORY RANDOM",
                    f"#TITLE {padded_folder_name} RANDOM",
                    "#INFORMATION_A",
                    "#INFORMATION_B"
                ]
                content = "\n".join(lines) + "\n"
                
                filename = f"random_{idx:03d}_difficulty_{idx:02d}.lr2folder"
                filepath = random_folder / filename
                
                with open(filepath, 'w', encoding=self.encoding) as f:
                    f.write(content)
                
                created_files.append(filename)
            
            if include_all_random:
                all_random_idx = len(self.difficulties)
                lines = [
                    f"#COMMAND song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND is_removed = 0)",
                    "#MAXTRACKS 1",
                    "#CATEGORY RANDOM",
                    "#TITLE ALL RANDOM",
                    "#INFORMATION_A",
                    "#INFORMATION_B"
                ]
                content = "\n".join(lines) + "\n"
                
                filename = f"random_{all_random_idx:03d}_all.lr2folder"
                filepath = random_folder / filename
                
                with open(filepath, 'w', encoding=self.encoding) as f:
                    f.write(content)
                
                created_files.append(filename)
            
            return True, f"生成完了: {len(created_files)}個のファイルを作成しました\n\nフォルダ: {random_folder}\n\n" + "\n".join(created_files)
        
        except Exception as e:
            return False, f"生成エラー: {str(e)}"


class BPMFolderGenerator(FolderGenerator):
    """BPMフォルダ生成クラス"""
    
    def __init__(self):
        super().__init__()
        self.db_path = None  # ユーザーが選択したデータベースパス
    
    BPM_RANGES = [
        (0, 99),
        (100, 109), (110, 119), (120, 129), (130, 139), (140, 149),
        (150, 159), (160, 169), (170, 179), (180, 189), (190, 199),
        (200, 209), (210, 219), (220, 229), (230, 239), (240, 249),
        (250, 259), (260, 269), (270, 279), (280, 289), (290, 299),
        (300, 9999)
    ]
    
    def _count_songs_in_folder(self, folder_name, min_bpm, max_bpm):
        """
        データベースから、指定された難易度とBPM範囲の曲数をカウント
        """
        if not self.db_path:
            # データベースが選択されていない場合は、曲があると仮定
            return 1
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if max_bpm == 9999:
                query = f"SELECT COUNT(*) FROM song WHERE hash IN (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND folder = '{folder_name}' AND is_removed = 0) AND maxbpm >= {min_bpm}"
            else:
                query = f"SELECT COUNT(*) FROM song WHERE hash IN (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND folder = '{folder_name}' AND is_removed = 0) AND maxbpm >= {min_bpm} AND maxbpm <= {max_bpm}"
            
            cursor.execute(query)
            count = cursor.fetchone()[0]
            conn.close()
            
            return count
        except Exception as e:
            # エラーの場合は、曲があると仮定
            return 1
    
    def create_bpm_folders(self, include_all_bpm=True, delete_empty=False):
        """BPMフォルダを生成"""
        if not self.folder_path or not self.difficulties or not self.playlist_id:
            return False, "フォルダ情報が不完全です"
        
        # 親ディレクトリにBPMフォルダを作成（難易度表と同じ階層）
        parent_folder = Path(self.folder_path).parent
        folder_name = Path(self.folder_path).name
        bpm_folder = parent_folder / f"{folder_name} BPM"
        
        # 既存フォルダ内のファイルをクリア
        if bpm_folder.exists():
            # 旧フォルダ構造完全削除
            shutil.rmtree(bpm_folder)
        bpm_folder.mkdir(exist_ok=True)
        
        created_folders = []
        created_files = []
        
        try:
            # 難易度ごとのBPMフォルダ
            for diff_idx, (folder_name, title) in enumerate(self.difficulties):
                # folder_name 内の数値をパッド付けしてソート順を正しくする
                padded_folder_name = self._pad_folder_name(folder_name)
                # ファイルシステム用にサニタイズ
                safe_folder_name = self._sanitize_filename(padded_folder_name)
                diff_bpm_folder = bpm_folder / safe_folder_name
                diff_bpm_folder.mkdir(exist_ok=True)
                created_folders.append(safe_folder_name)
                
                file_count = 0
                song_count = 0  # 実際の曲数
                for range_idx, bpm_range in enumerate(self.BPM_RANGES):
                    min_bpm, max_bpm = bpm_range
                    
                    if max_bpm == 9999:
                        label = "300+"
                        cmd = f"song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND folder = '{folder_name}' AND is_removed = 0) AND maxbpm >= {min_bpm}"
                    else:
                        label = f"{min_bpm}-{max_bpm}"
                        cmd = f"song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND folder = '{folder_name}' AND is_removed = 0) AND maxbpm >= {min_bpm} AND maxbpm <= {max_bpm}"
                    
                    lines = [
                        f"#COMMAND {cmd}",
                        "#MAXTRACKS 0",
                        "#CATEGORY BPM",
                        f"#TITLE {padded_folder_name} {label}",
                        "#INFORMATION_A",
                        "#INFORMATION_B"
                    ]
                    content = "\n".join(lines) + "\n"
                    
                    filename = f"bpm_{range_idx:02d}_{label}.lr2folder"
                    filepath = diff_bpm_folder / filename
                    
                    with open(filepath, 'w', encoding=self.encoding) as f:
                        f.write(content)
                    
                    created_files.append(filename)
                    file_count += 1
                    
                    # データベースから実際の曲数をカウント
                    if delete_empty:
                        count = self._count_songs_in_folder(folder_name, min_bpm, max_bpm)
                        song_count += count
                
                # delete_empty が True で、かつこの難易度に曲がない場合はフォルダを削除
                if delete_empty and song_count == 0:
                    shutil.rmtree(diff_bpm_folder)
                    created_folders.pop()
            
            # 全曲BPMフォルダ
            if include_all_bpm:
                all_bpm_folder = bpm_folder / "ALL"
                all_bpm_folder.mkdir(exist_ok=True)
                created_folders.append("ALL")
                
                for range_idx, bpm_range in enumerate(self.BPM_RANGES):
                    min_bpm, max_bpm = bpm_range
                    
                    if max_bpm == 9999:
                        label = "300+"
                        cmd = f"song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND is_removed = 0) AND maxbpm >= {min_bpm}"
                    else:
                        label = f"{min_bpm}-{max_bpm}"
                        cmd = f"song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND is_removed = 0) AND maxbpm >= {min_bpm} AND maxbpm <= {max_bpm}"
                    
                    lines = [
                        f"#COMMAND {cmd}",
                        "#MAXTRACKS 0",
                        "#CATEGORY BPM",
                        f"#TITLE ALL {label}",
                        "#INFORMATION_A",
                        "#INFORMATION_B"
                    ]
                    content = "\n".join(lines) + "\n"
                    
                    filename = f"bpm_{range_idx:02d}_{label}.lr2folder"
                    filepath = all_bpm_folder / filename
                    
                    with open(filepath, 'w', encoding=self.encoding) as f:
                        f.write(content)
                    
                    created_files.append(filename)
            
            return True, f"生成完了: {len(created_folders)}個のフォルダを作成しました\n\nフォルダ: {bpm_folder}\n\n作成フォルダ:\n" + "\n".join(created_folders)
        
        except Exception as e:
            return False, f"生成エラー: {str(e)}"


class BPFolderGenerator(FolderGenerator):
    """BP（Almost Full Combo）フォルダ生成クラス"""
    
    def create_bp_folders(self):
        """BP1～BP9フォルダを生成"""
        if not self.folder_path or not self.playlist_id:
            return False, "フォルダ情報が不完全です"
        
        # 難易度表フォルダ内に「ALMOST FULL COMBO」フォルダを作成
        bp_folder = Path(self.folder_path) / "ALMOST FULL COMBO"
        # 既存ファイルをクリア
        if bp_folder.exists():
            for file in bp_folder.glob('*.lr2folder'):
                file.unlink()
        bp_folder.mkdir(exist_ok=True)
        
        created_files = []
        
        try:
            # BP1～BP9のファイルを生成
            for bp_value in range(1, 10):
                cmd = f"song.hash in (SELECT md5 FROM playlist_entry WHERE playlist_id = {self.playlist_id} AND is_removed = 0) AND minbp = {bp_value} AND clear != 5"
                
                lines = [
                    f"#COMMAND {cmd}",
                    "#MAXTRACKS 0",
                    "#CATEGORY Almost Full Combo",
                    f"#TITLE BP{bp_value}",
                    "#INFORMATION_A",
                    "#INFORMATION_B"
                ]
                content = "\n".join(lines) + "\n"
                
                filename = f"bp_{bp_value:03d}_{bp_value}.lr2folder"
                filepath = bp_folder / filename
                
                with open(filepath, 'w', encoding=self.encoding) as f:
                    f.write(content)
                
                created_files.append(filename)
            
            return True, f"生成完了: {len(created_files)}個のファイルを作成しました\n\nフォルダ: {bp_folder}\n\n" + "\n".join(created_files)
        
        except Exception as e:
            return False, f"生成エラー: {str(e)}"


class FolderGeneratorApp:
    """メインアプリケーション（タブ方式）"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("LR2 Folder Generator")
        self.root.geometry("650x550")
        self.root.resizable(False, False)
        
        self.random_gen = RandomFolderGenerator()
        self.bpm_gen = BPMFolderGenerator()
        self.bp_gen = BPFolderGenerator()
        
        self.create_widgets()
    
    def create_widgets(self):
        """UI要素を作成"""
        # タイトル
        title_frame = ttk.Frame(self.root)
        title_frame.pack(pady=10)
        title_label = ttk.Label(title_frame, text="LR2 Folder Generator", font=("Arial", 14, "bold"))
        title_label.pack()
        
        # タブコントロール
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Tab1: RANDOM
        random_frame = ttk.Frame(notebook, padding=10)
        notebook.add(random_frame, text="RANDOM")
        self.create_random_tab(random_frame)
        
        # Tab2: BPM
        bpm_frame = ttk.Frame(notebook, padding=10)
        notebook.add(bpm_frame, text="BPM")
        self.create_bpm_tab(bpm_frame)
        
        # Tab3: BP
        bp_frame = ttk.Frame(notebook, padding=10)
        notebook.add(bp_frame, text="BP")
        self.create_bp_tab(bp_frame)
    
    def create_random_tab(self, parent):
        """RANDOMタブ作成"""
        # フォルダ選択
        folder_frame = ttk.LabelFrame(parent, text="フォルダ選択", padding=10)
        folder_frame.pack(fill="x", pady=5)
        
        ttk.Label(folder_frame, text="難易度表フォルダ:").grid(row=0, column=0, sticky="w")
        self.random_folder_var = tk.StringVar()
        ttk.Entry(folder_frame, textvariable=self.random_folder_var, width=45).grid(row=1, column=0, sticky="ew", pady=5)
        ttk.Button(folder_frame, text="参照", command=lambda: self._select_folder(self.random_folder_var)).grid(row=1, column=1, padx=5)
        folder_frame.columnconfigure(0, weight=1)
        
        # 検出ボタン
        ttk.Button(parent, text="難易度を自動検出", command=self._detect_random).pack(pady=5)
        
        # 難易度表示
        difficulty_frame = ttk.LabelFrame(parent, text="検出された難易度", padding=5)
        difficulty_frame.pack(fill="both", expand=True, pady=5)
        
        self.random_difficulty_text = scrolledtext.ScrolledText(difficulty_frame, height=6, width=60, state="disabled")
        self.random_difficulty_text.pack(fill="both", expand=True)
        
        # 設定
        config_frame = ttk.LabelFrame(parent, text="設定", padding=10)
        config_frame.pack(fill="x", pady=5)
        
        self.random_all_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(config_frame, text="全曲ランダムフォルダも作成する", variable=self.random_all_var).pack(anchor="w")
        
        # ボタン
        button_frame = ttk.Frame(parent)
        button_frame.pack(pady=10)
        ttk.Button(button_frame, text="生成開始", command=self._generate_random).pack(side="left", padx=5)
    
    def create_bpm_tab(self, parent):
        """BPMタブ作成"""
        # フォルダ選択
        folder_frame = ttk.LabelFrame(parent, text="フォルダ選択", padding=10)
        folder_frame.pack(fill="x", pady=5)
        
        ttk.Label(folder_frame, text="難易度表フォルダ:").grid(row=0, column=0, sticky="w")
        self.bpm_folder_var = tk.StringVar()
        ttk.Entry(folder_frame, textvariable=self.bpm_folder_var, width=45).grid(row=1, column=0, sticky="ew", pady=5)
        ttk.Button(folder_frame, text="参照", command=lambda: self._select_folder(self.bpm_folder_var)).grid(row=1, column=1, padx=5)
        
        folder_frame.columnconfigure(0, weight=1)
        
        # 検出ボタン
        ttk.Button(parent, text="難易度を自動検出", command=self._detect_bpm).pack(pady=5)
        
        # 難易度表示
        difficulty_frame = ttk.LabelFrame(parent, text="検出された難易度", padding=5)
        difficulty_frame.pack(fill="both", expand=True, pady=5)
        
        self.bpm_difficulty_text = scrolledtext.ScrolledText(difficulty_frame, height=4, width=60, state="disabled")
        self.bpm_difficulty_text.pack(fill="both", expand=True)
        
        # 設定
        config_frame = ttk.LabelFrame(parent, text="設定", padding=10)
        config_frame.pack(fill="x", pady=5)
        
        self.bpm_all_var = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(config_frame, text="全曲BPMフォルダも作成する", variable=self.bpm_all_var).pack(anchor="w")
        
        # ボタン
        button_frame = ttk.Frame(parent)
        button_frame.pack(pady=10)
        ttk.Button(button_frame, text="生成開始", command=self._generate_bpm).pack(side="left", padx=5)
    
    def create_bp_tab(self, parent):
        """BPタブ作成"""
        # フォルダ選択
        folder_frame = ttk.LabelFrame(parent, text="フォルダ選択", padding=10)
        folder_frame.pack(fill="x", pady=5)
        
        ttk.Label(folder_frame, text="難易度表フォルダ:").grid(row=0, column=0, sticky="w")
        self.bp_folder_var = tk.StringVar()
        ttk.Entry(folder_frame, textvariable=self.bp_folder_var, width=45).grid(row=1, column=0, sticky="ew", pady=5)
        ttk.Button(folder_frame, text="参照", command=lambda: self._select_folder(self.bp_folder_var)).grid(row=1, column=1, padx=5)
        
        folder_frame.columnconfigure(0, weight=1)
        
        # 検出ボタン
        ttk.Button(parent, text="難易度を自動検出", command=self._detect_bp).pack(pady=5)
        
        # 難易度表示
        difficulty_frame = ttk.LabelFrame(parent, text="検出された難易度", padding=5)
        difficulty_frame.pack(fill="both", expand=True, pady=5)
        
        self.bp_difficulty_text = scrolledtext.ScrolledText(difficulty_frame, height=4, width=60, state="disabled")
        self.bp_difficulty_text.pack(fill="both", expand=True)
        
        # ボタン
        button_frame = ttk.Frame(parent)
        button_frame.pack(pady=10)
        ttk.Button(button_frame, text="生成開始", command=self._generate_bp).pack(side="left", padx=5)
    
    def _select_folder(self, var):
        """フォルダ選択ダイアログ"""
        folder = filedialog.askdirectory(
            title="難易度表フォルダを選択",
            initialdir="E:\\カスタムフォルダ"
        )
        if folder:
            var.set(folder)
    
    def _detect_random(self):
        """RANDOM難易度検出"""
        folder_path = self.random_folder_var.get()
        if not folder_path or not os.path.isdir(folder_path):
            messagebox.showerror("エラー", "有効なフォルダを選択してください")
            return
        
        self.random_gen.folder_path = folder_path
        success, message = self.random_gen.detect_difficulties(folder_path)
        
        if not success:
            messagebox.showerror("検出エラー", message)
            return
        
        self.random_difficulty_text.config(state="normal")
        self.random_difficulty_text.delete(1.0, tk.END)
        
        for folder_name, title in self.random_gen.difficulties:
            self.random_difficulty_text.insert(tk.END, f"• {folder_name}\n")
        
        self.random_difficulty_text.config(state="disabled")
        messagebox.showinfo("検出完了", message)
    
    def _detect_bpm(self):
        """BPM難易度検出"""
        folder_path = self.bpm_folder_var.get()
        if not folder_path or not os.path.isdir(folder_path):
            messagebox.showerror("エラー", "有効なフォルダを選択してください")
            return
        
        self.bpm_gen.folder_path = folder_path
        success, message = self.bpm_gen.detect_difficulties(folder_path)
        
        if not success:
            messagebox.showerror("検出エラー", message)
            return
        
        self.bpm_difficulty_text.config(state="normal")
        self.bpm_difficulty_text.delete(1.0, tk.END)
        
        for folder_name, title in self.bpm_gen.difficulties:
            self.bpm_difficulty_text.insert(tk.END, f"• {folder_name}\n")
        
        self.bpm_difficulty_text.config(state="disabled")
        messagebox.showinfo("検出完了", message)
    
    def _generate_random(self):
        """RANDOM生成"""
        if not self.random_gen.difficulties:
            messagebox.showerror("エラー", "まず難易度を検出してください")
            return
        
        thread = threading.Thread(target=self._generate_random_thread)
        thread.start()
    
    def _generate_random_thread(self):
        """RANDOM生成スレッド"""
        success, message = self.random_gen.create_random_folders(
            include_all_random=self.random_all_var.get()
        )
        
        if success:
            messagebox.showinfo("生成完了", message)
        else:
            messagebox.showerror("生成エラー", message)
    
    def _generate_bpm(self):
        """BPM生成"""
        if not self.bpm_gen.difficulties:
            messagebox.showerror("エラー", "まず難易度を検出してください")
            return
        
        thread = threading.Thread(target=self._generate_bpm_thread)
        thread.start()
    
    def _generate_bpm_thread(self):
        """BPM生成スレッド"""
        success, message = self.bpm_gen.create_bpm_folders(
            include_all_bpm=self.bpm_all_var.get(),
            delete_empty=False
        )
        
        if success:
            messagebox.showinfo("生成完了", message)
        else:
            messagebox.showerror("生成エラー", message)
    
    def _detect_bp(self):
        """BP難易度検出"""
        folder_path = self.bp_folder_var.get()
        if not folder_path or not os.path.isdir(folder_path):
            messagebox.showerror("エラー", "有効なフォルダを選択してください")
            return
        
        self.bp_gen.folder_path = folder_path
        success, message = self.bp_gen.detect_difficulties(folder_path)
        
        if not success:
            messagebox.showerror("検出エラー", message)
            return
        
        self.bp_difficulty_text.config(state="normal")
        self.bp_difficulty_text.delete(1.0, tk.END)
        
        for folder_name, title in self.bp_gen.difficulties:
            self.bp_difficulty_text.insert(tk.END, f"• {folder_name}\n")
        
        self.bp_difficulty_text.config(state="disabled")
        messagebox.showinfo("検出完了", message)
    
    def _generate_bp(self):
        """BP生成"""
        if not self.bp_gen.playlist_id:
            messagebox.showerror("エラー", "まず難易度を検出してください")
            return
        
        thread = threading.Thread(target=self._generate_bp_thread)
        thread.start()
    
    def _generate_bp_thread(self):
        """BP生成スレッド"""
        success, message = self.bp_gen.create_bp_folders()
        
        if success:
            messagebox.showinfo("生成完了", message)
        else:
            messagebox.showerror("生成エラー", message)


def main():
    """メイン処理"""
    root = tk.Tk()
    app = FolderGeneratorApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()
